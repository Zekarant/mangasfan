<?php
session_start();
require_once '../inc/base.php';
$user = $pdo->query("SELECT * FROM users WHERE username = '".$_SESSION['auth']->username."'")->fetch();
include('../inc/functions.php'); ?>
<html>
<head>
<title>Mangas'Fan - Accueil des jeux vidéos</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<link rel="icon" href="../images/favicon.png"/>
	<link href="https://fonts.googleapis.com/css?family=Oswald" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
	<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="../style.css">
</head>
<body>
<header>
	<div id="banniere_image">
	<div id="titre_site"><span class="couleur_mangas">M</span>ANGAS'<span class="couleur_fans">F</span>AN</div>
	<div class="slogan_site">Votre référence Mangas</div>
        <?php include("../elements/navigation.php") ?>
	<h2 id="actu_moment">NOTRE FORUM</h2>
	<h5 id="slogan_actu">Pour parler de notre passion commune</h5>
	<div class="bouton_fofo"><a href="http://www.mangasfan.pe.hu/forum">Forum</a></div>
   <?php include('../elements/header.php'); ?>
         <section>
		  <center><div class="alert alert-info" role="alert"><b>Avis : </b>Cette page est encore en construction ! On ne peut pas donner de dates de fin ! Elle est encore en développement !</div></center>
		 <?php include("../elements/messages.php"); ?>

		 <div id="conteneur_images_jeux">
		  <?php
            $req = $pdo->query('SELECT *, billets.id AS id_billet, DATE_FORMAT(billets.date_creation, \'%d %M %Y à %Hh %imin\') AS date_creation_fr
FROM billets_jeux
ORDER BY date_creation DESC
');
            //rajouter le pseudo et une image ainsi que la catégorie de la news
            while ($donnees = $req->fetch())
            {
            ?>
		<div class="gallery">
  <a target="_blank" href="dokkanbattle/index.php">
   <div class="image_jeux"><?php echo $donnees->theme; ?></div>
  </a>
  <div class="desc"><?php echo bbcode($donnees->titre); ?></div>
</div>
  <?php
                } // Fin de la boucle des billets
                $req->closeCursor();
                ?>
</div>

	<div id="banniere_image_deux">
            <div id="twitter"><?php include('../elements/twitter.php') ?></div>
            <div id="discord"><?php include('../elements/discord.php') ?></div>
	        </div>
			</section>
			<?php include('../elements/footer.php'); ?>
		
	</body>
</html>

